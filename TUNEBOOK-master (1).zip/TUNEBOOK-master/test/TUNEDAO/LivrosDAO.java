package TUNEDAO;

import CONEXAO.ConexaoTune;
import MODELS.LivrosModel;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LivrosDAO {

    public void CreateLivros(LivrosModel livros) {

        String sql = "INSERT INTO livro (titulo, autor, genero) VALUES(?,?,?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, livros.getTitulo());
            preparedStatement.setString(2, livros.getAutor());
            preparedStatement.setString(3, livros.getGenero());

            preparedStatement.execute();
            JOptionPane.showMessageDialog(null, "Livro cadastrado com sucesso");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public List<LivrosModel> ShowLivros() {

        String sql = "SELECT * FROM livro";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ArrayList<LivrosModel> livross = new ArrayList<>();
        //classe que vai recuperar os dados do banco.
        ResultSet resultSet = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                LivrosModel livros = new LivrosModel();

                System.out.println("id do livro: " + resultSet.getInt("id_livro"));
                System.out.println("titulo do livro: " + resultSet.getString("titulo"));
                System.out.println("autor do livro: " + resultSet.getString("autor"));
                System.out.println("genero do livro: " + resultSet.getString("genero"));

                System.out.println("======================= ===================");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return livross;
    }

    public void UpdateLivros(LivrosModel livros) {

        String sql = "UPDATE  livro SET titulo=?, autor=?,genero=? WHERE id_livro=?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, livros.getId_livro());
            preparedStatement.setString(2, livros.getTitulo());
            preparedStatement.setString(3, livros.getAutor());
            preparedStatement.setString(3, livros.getGenero());

            preparedStatement.execute();

            JOptionPane.showMessageDialog(null, " livro atualizado com sucesso");

        } catch (Exception exception) {

            System.out.println("Erro: " + exception);
        }
    }

    public static void DeleteClientes(int id_livro) {

        String sql = "DELETE FROM livro WHERE id_livro = ?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id_livro);

            preparedStatement.execute();

            JOptionPane.showMessageDialog(null, "livro deletado com sucesso");

        } catch (Exception exception) {

            JOptionPane.showMessageDialog(null, exception);

        }

    }
}

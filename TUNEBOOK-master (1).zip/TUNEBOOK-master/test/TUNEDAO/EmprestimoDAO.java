package TUNEDAO;

import CONEXAO.ConexaoTune;
import MODELS.EmprestimoModel;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmprestimoDAO {

    public void CreateEmprestimo(EmprestimoModel emprestimo) {

        String sql = "INSERT INTO emprestimo (data_emprestimo, valor_emprestimo,prazo_emprestimo, fk_clientes_id_clientes) VALUES(?,?,?,?)";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, emprestimo.getData_emprestimo());
            preparedStatement.setInt(2, emprestimo.getPrazo_emprestimo());
            preparedStatement.setInt(3, emprestimo.getValor_emprestimo());
            preparedStatement.setInt(4, emprestimo.getFk_clientes_id_clientes());
            

            preparedStatement.execute();

            JOptionPane.showMessageDialog(null, "emprestimo feito com sucesso");

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public List<EmprestimoModel> ShowEmprestimo() {

        String sql = "SELECT * FROM emprestimo";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        ArrayList<EmprestimoModel> emprestimos = new ArrayList<>();
        //classe que vai recuperar os dados do banco.
        ResultSet resultSet = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                EmprestimoModel emprestimo = new EmprestimoModel();

                System.out.println("id do emprestimo: " + resultSet.getInt("id_emprestimo"));
                System.out.println("data do emprestimo: " + resultSet.getInt("data_emprestimo"));
                System.out.println("valor do emprestimo " + resultSet.getInt("valor_emprestimo"));
                System.out.println("prazo do emprestimo " + resultSet.getInt("prazo_emprestimo"));
                System.out.println("Id do cliente " + resultSet.getInt("Fk_clientes_id_clientes"));
                System.out.println("======================= ===================");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return emprestimos;
    }

    public void UpdateEmprestimo(EmprestimoModel emprestimo) {

        String sql = "UPDATE  emprestimo SET data_emprestimo=?, valor_emprestimo=?, prazo_emprestimo=?, Fk_clientes_id_clientes WHERE id_emprestimo=?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, emprestimo.getId_emprestimo());
            preparedStatement.setInt(2,  emprestimo.getData_emprestimo());;
            preparedStatement.setInt(3,  emprestimo.getPrazo_emprestimo());
            preparedStatement.setInt(4, emprestimo.getValor_emprestimo());
            preparedStatement.setInt(5, emprestimo.getFk_clientes_id_clientes());

            preparedStatement.execute();

            JOptionPane.showMessageDialog(null, " dados do emprestimo atualizados com sucesso");

        } catch (Exception exception) {

            System.out.println("Erro: " + exception);
        }
    }

    public static void DeleteEmprestimo(int id) {

        String sql = "DELETE FROM emprestimo WHERE id_emprestimo = ?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {

            connection = ConexaoTune.conexaoMySQL();
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            JOptionPane.showMessageDialog(null, "Emprestimo deletado com sucesso");

        } catch (Exception exception) {

            JOptionPane.showMessageDialog(null, exception);

        }

    }

}

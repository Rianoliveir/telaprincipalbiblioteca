package MODELS;

public class EmprestimoModel {

    private int id_emprestimo;

    private int data_emprestimo;

    private int valor_emprestimo;

    private int prazo_emprestimo;
    
    private int fk_clientes_id_clientes;

    public EmprestimoModel() {
    
    }

    public EmprestimoModel(int id_emprestimo, int data_emprestimo, int valor_emprestimo, int prazo_emprestimo, int fk_clientes_id_clientes) {
        this.id_emprestimo = id_emprestimo;
        this.data_emprestimo = data_emprestimo;
        this.valor_emprestimo = valor_emprestimo;
        this.prazo_emprestimo = prazo_emprestimo;
        this.fk_clientes_id_clientes = fk_clientes_id_clientes;
    }

    public int getId_emprestimo() {
        return id_emprestimo;
    }

    public void setId_emprestimo(int id_emprestimo) {
        this.id_emprestimo = id_emprestimo;
    }

    public int getData_emprestimo() {
        return data_emprestimo;
    }

    public void setData_emprestimo(int data_emprestimo) {
        this.data_emprestimo = data_emprestimo;
    }

    public int getValor_emprestimo() {
        return valor_emprestimo;
    }

    public void setValor_emprestimo(int valor_emprestimo) {
        this.valor_emprestimo = valor_emprestimo;
    }

    public int getPrazo_emprestimo() {
        return prazo_emprestimo;
    }

    public void setPrazo_emprestimo(int prazo_emprestimo) {
        this.prazo_emprestimo = prazo_emprestimo;
    }

    public int getFk_clientes_id_clientes() {
        return fk_clientes_id_clientes;
    }

    public void setFk_clientes_id_clientes(int fk_clientes_id_clientes) {
        this.fk_clientes_id_clientes = fk_clientes_id_clientes;
    }

    
    
    
}
